import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Check, i as ChevronLeft, n as ClipboardList, o as ChartColumn, r as ChevronRight } from "../_libs/lucide-react.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { a as Area, c as ResponsiveContainer, i as XAxis, l as Tooltip, n as BarChart, o as CartesianGrid, r as YAxis, s as Bar, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CEHn1dK8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[color,background-color,box-shadow,transform,opacity] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:bg-accent/90",
			secondary: "bg-surface text-fg shadow-[var(--shadow-border)] hover:bg-bg-warm",
			ghost: "text-fg hover:bg-bg-warm",
			outline: "border border-border bg-transparent text-fg hover:bg-bg-warm"
		},
		size: {
			default: "h-10 px-4",
			sm: "h-8 px-3 text-sm",
			lg: "h-11 px-5",
			icon: "size-10",
			"icon-sm": "size-8"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, static: isStatic, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), !isStatic && "active:not-disabled:scale-[0.96]", className),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-10 w-full rounded-md border border-border bg-surface-raised px-3 text-sm text-fg shadow-[var(--shadow-border)] transition-[border-color,box-shadow] duration-150 placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40 disabled:cursor-not-allowed disabled:opacity-50", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var SLEEP_HOURS = [
	9,
	8,
	7,
	6,
	5
];
var DEFAULT_HABIT_NAMES = [
	"Wake by 6:30",
	"Make the bed",
	"Drink 3L water",
	"Train",
	"Read 20 min",
	"No added sugar",
	"Walk 8k steps",
	"Stretch",
	"Journal",
	"Phone away by 10"
];
function defaultHabits() {
	return DEFAULT_HABIT_NAMES.map((name, i) => ({
		id: `h${i + 1}`,
		name
	}));
}
function checkKey(habitId, day) {
	return `${habitId}:${day}`;
}
function monthKey(date = /* @__PURE__ */ new Date()) {
	return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}
function parseMonthKey(key) {
	const [ys, ms] = key.split("-");
	return {
		year: Number(ys),
		month: Number(ms)
	};
}
function daysInMonthKey(key) {
	const { year, month } = parseMonthKey(key);
	return new Date(year, month, 0).getDate();
}
function shiftMonth(key, delta) {
	const { year, month } = parseMonthKey(key);
	return monthKey(new Date(year, month - 1 + delta, 1));
}
function formatMonthLabel(key) {
	const { year, month } = parseMonthKey(key);
	return new Date(year, month - 1, 1).toLocaleDateString("en-US", {
		month: "long",
		year: "numeric"
	});
}
function formatMonthShort(key) {
	const { year, month } = parseMonthKey(key);
	return new Date(year, month - 1, 1).toLocaleDateString("en-US", {
		month: "short",
		year: "numeric"
	});
}
function weekday(key, day) {
	const { year, month } = parseMonthKey(key);
	return new Date(year, month - 1, day).getDay();
}
function isWeekend(key, day) {
	const wd = weekday(key, day);
	return wd === 0 || wd === 6;
}
function weekdayLetter(key, day) {
	return [
		"S",
		"M",
		"T",
		"W",
		"T",
		"F",
		"S"
	][weekday(key, day)] ?? "";
}
function todayInfo() {
	const now = /* @__PURE__ */ new Date();
	return {
		key: monthKey(now),
		day: now.getDate()
	};
}
function emptySheet(personName = "", habits = defaultHabits()) {
	return {
		personName,
		habits: habits.map((h) => ({ ...h })),
		checks: {},
		sleep: {},
		notes: ""
	};
}
function activeHabits(sheet) {
	return sheet.habits.filter((h) => h.name.trim().length > 0);
}
function seedSheet(key) {
	const sheet = emptySheet();
	const dim = daysInMonthKey(key);
	const today = todayInfo();
	const lastElapsed = key < today.key ? dim : key === today.key ? today.day : 0;
	const fillUntil = Math.max(0, lastElapsed - (key === today.key ? 1 : 0));
	const rates = [
		.92,
		.78,
		.86,
		.64,
		.72,
		.7,
		.58,
		.68,
		.54,
		.88
	];
	for (let hi = 0; hi < 10; hi++) {
		const habit = sheet.habits[hi];
		if (!habit) continue;
		const rate = rates[hi] ?? .7;
		for (let day = 1; day <= fillUntil; day++) if ((hi * 31 + day * 17 + 7) % 100 < rate * 100) sheet.checks[checkKey(habit.id, day)] = true;
	}
	const sleepCycle = [
		7,
		8,
		7,
		8,
		6,
		9,
		8
	];
	for (let day = 1; day <= fillUntil; day++) sheet.sleep[String(day)] = sleepCycle[(day - 1) % 7] ?? 7;
	if (key === today.key && fillUntil > 0) sheet.notes = "Training felt strong this week. Keep water and bedtime consistent — sleep dipped midweek.";
	return sheet;
}
var noopStorage = {
	getItem: () => null,
	setItem: () => {},
	removeItem: () => {}
};
function latestHabitsAndName(months) {
	const last = Object.keys(months).sort().at(-1);
	if (!last) return {
		personName: "",
		habits: emptySheet().habits
	};
	const sheet = months[last];
	if (!sheet) return {
		personName: "",
		habits: emptySheet().habits
	};
	return {
		personName: sheet.personName,
		habits: sheet.habits
	};
}
function ensureMonth(months, key) {
	if (months[key]) return months;
	const { personName, habits } = latestHabitsAndName(months);
	return {
		...months,
		[key]: emptySheet(personName, habits)
	};
}
var initialKey = monthKey();
var useHabitStore = create()(persist((set, get) => ({
	months: { [initialKey]: seedSheet(initialKey) },
	activeMonth: initialKey,
	view: "sheet",
	setView: (view) => set({ view }),
	setActiveMonth: (key) => {
		set({
			months: ensureMonth(get().months, key),
			activeMonth: key
		});
	},
	stepMonth: (delta) => {
		const next = shiftMonth(get().activeMonth, delta);
		set({
			months: ensureMonth(get().months, next),
			activeMonth: next
		});
	},
	setPersonName: (name) => {
		const { activeMonth, months } = get();
		const sheet = months[activeMonth];
		if (!sheet) return;
		set({ months: {
			...months,
			[activeMonth]: {
				...sheet,
				personName: name
			}
		} });
	},
	setHabitName: (habitId, name) => {
		const { activeMonth, months } = get();
		const sheet = months[activeMonth];
		if (!sheet) return;
		set({ months: {
			...months,
			[activeMonth]: {
				...sheet,
				habits: sheet.habits.map((h) => h.id === habitId ? {
					...h,
					name
				} : h)
			}
		} });
	},
	toggleCheck: (habitId, day) => {
		const { activeMonth, months } = get();
		const sheet = months[activeMonth];
		if (!sheet) return;
		const key = `${habitId}:${day}`;
		const next = { ...sheet.checks };
		if (next[key]) delete next[key];
		else next[key] = true;
		set({ months: {
			...months,
			[activeMonth]: {
				...sheet,
				checks: next
			}
		} });
	},
	setSleep: (day, hours) => {
		const { activeMonth, months } = get();
		const sheet = months[activeMonth];
		if (!sheet) return;
		const next = { ...sheet.sleep };
		const k = String(day);
		if (hours === null || next[k] === hours) delete next[k];
		else next[k] = hours;
		set({ months: {
			...months,
			[activeMonth]: {
				...sheet,
				sleep: next
			}
		} });
	},
	setNotes: (notes) => {
		const { activeMonth, months } = get();
		const sheet = months[activeMonth];
		if (!sheet) return;
		set({ months: {
			...months,
			[activeMonth]: {
				...sheet,
				notes
			}
		} });
	},
	clearMonth: () => {
		const { activeMonth, months } = get();
		const sheet = months[activeMonth];
		if (!sheet) return;
		set({ months: {
			...months,
			[activeMonth]: {
				...sheet,
				checks: {},
				sleep: {},
				notes: ""
			}
		} });
	},
	resetToDefaults: () => {
		const key = monthKey();
		set({
			months: { [key]: seedSheet(key) },
			activeMonth: key,
			view: "sheet"
		});
	}
}), {
	name: "small-habits.v1",
	skipHydration: true,
	storage: createJSONStorage(() => typeof window === "undefined" ? noopStorage : localStorage),
	partialize: (state) => ({
		months: state.months,
		activeMonth: state.activeMonth
	})
}));
function useActiveSheet() {
	return useHabitStore((s) => {
		return s.months[s.activeMonth] ?? emptySheet();
	});
}
function AppHeader() {
	const activeMonth = useHabitStore((s) => s.activeMonth);
	const view = useHabitStore((s) => s.view);
	const stepMonth = useHabitStore((s) => s.stepMonth);
	const setView = useHabitStore((s) => s.setView);
	const setPersonName = useHabitStore((s) => s.setPersonName);
	const sheet = useActiveSheet();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex flex-col gap-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-[0.18em] text-muted uppercase",
					children: "Small habits. Big change."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-3xl font-semibold tracking-tight text-fg sm:text-4xl",
					children: "Habit ledger"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "no-print grid grid-cols-2 rounded-full bg-bg-warm p-1 self-start sm:self-auto",
				role: "tablist",
				"aria-label": "View",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					role: "tab",
					"aria-selected": view === "sheet",
					onClick: () => setView("sheet"),
					className: cn("inline-flex h-9 items-center justify-center gap-1.5 rounded-full px-4 text-sm font-medium transition-[background-color,color,box-shadow] duration-150", view === "sheet" ? "bg-surface text-fg shadow-[var(--shadow-border)]" : "text-muted hover:text-fg"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, { className: "size-3.5" }), "Sheet"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					role: "tab",
					"aria-selected": view === "report",
					onClick: () => setView("report"),
					className: cn("inline-flex h-9 items-center justify-center gap-1.5 rounded-full px-4 text-sm font-medium transition-[background-color,color,box-shadow] duration-150", view === "report" ? "bg-surface text-fg shadow-[var(--shadow-border)]" : "text-muted hover:text-fg"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "size-3.5" }), "Report"]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						className: "no-print size-11",
						onClick: () => stepMonth(-1),
						"aria-label": "Previous month",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "min-w-40 text-center font-display text-xl font-medium tracking-tight tabular-nums",
						children: formatMonthLabel(activeMonth)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						className: "no-print size-11",
						onClick: () => stepMonth(1),
						"aria-label": "Next month",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex min-w-0 items-center gap-2 sm:max-w-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "shrink-0 text-xs font-medium tracking-wide text-muted uppercase",
					children: "Name"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: sheet.personName,
					onChange: (e) => setPersonName(e.target.value),
					placeholder: "Your name",
					"aria-label": "Your name",
					className: "h-11 bg-surface-raised"
				})]
			})]
		})]
	});
}
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-32 w-full rounded-lg border border-border bg-surface-raised px-4 py-3 text-sm leading-normal text-fg shadow-[var(--shadow-border)] transition-[border-color,box-shadow] duration-150 placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40 disabled:cursor-not-allowed disabled:opacity-50", className),
		ref,
		...props
	});
});
Textarea.displayName = "Textarea";
function dayList(dim) {
	return Array.from({ length: dim }, (_, i) => i + 1);
}
function HabitSheet() {
	const activeMonth = useHabitStore((s) => s.activeMonth);
	const setHabitName = useHabitStore((s) => s.setHabitName);
	const toggleCheck = useHabitStore((s) => s.toggleCheck);
	const setSleep = useHabitStore((s) => s.setSleep);
	const setNotes = useHabitStore((s) => s.setNotes);
	const clearMonth = useHabitStore((s) => s.clearMonth);
	const sheet = useActiveSheet();
	const days = dayList(daysInMonthKey(activeMonth));
	const today = todayInfo();
	const scroller = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (activeMonth !== today.key) return;
		(scroller.current?.querySelector(`[data-day="${today.day}"]`))?.scrollIntoView({
			inline: "center",
			block: "nearest"
		});
	}, [
		activeMonth,
		today.day,
		today.key
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "sheet-card overflow-hidden rounded-2xl bg-surface shadow-[var(--shadow-sheet)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 border-b border-border px-4 py-3 sm:px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-[0.14em] text-muted uppercase",
					children: "Habits / days"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "hidden text-xs text-subtle sm:block",
					children: "Tap a cell to mark it. Unused rows stay blank."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: scroller,
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-max min-w-full border-collapse text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							scope: "col",
							className: "sticky left-0 z-20 min-w-40 bg-surface px-3 py-2 text-left text-xs font-medium tracking-wide text-muted uppercase shadow-[1px_0_0_0_var(--color-border)]",
							children: "Habit"
						}),
						days.map((day) => {
							const isToday = activeMonth === today.key && day === today.day;
							const weekend = isWeekend(activeMonth, day);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("th", {
								scope: "col",
								"data-day": day,
								className: cn("min-w-9 px-0 py-1.5 text-center font-medium tabular-nums", isToday ? "bg-today text-accent" : weekend ? "bg-weekend text-muted" : "text-muted"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs font-medium leading-none text-subtle",
									children: weekdayLetter(activeMonth, day)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-0.5 block text-xs leading-none",
									children: day
								})]
							}, day);
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							scope: "col",
							className: "min-w-12 bg-surface px-2 py-2 text-right text-xs font-medium tracking-wide text-muted uppercase",
							children: "Sum"
						})
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: sheet.habits.map((habit, index) => {
						const done = days.reduce((n, day) => n + (sheet.checks[checkKey(habit.id, day)] ? 1 : 0), 0);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									scope: "row",
									className: "sticky left-0 z-10 bg-surface px-1 py-0 shadow-[1px_0_0_0_var(--color-border)]",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "w-5 shrink-0 text-right text-xs tabular-nums text-subtle",
											children: [index + 1, "."]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: habit.name,
											onChange: (e) => setHabitName(habit.id, e.target.value),
											placeholder: "Add a habit",
											"aria-label": `Habit ${index + 1} name`,
											className: "h-10 min-w-0 flex-1 bg-transparent px-1 text-sm font-medium text-fg outline-none placeholder:font-normal placeholder:text-subtle"
										})]
									})
								}),
								days.map((day) => {
									const on = Boolean(sheet.checks[checkKey(habit.id, day)]);
									const isToday = activeMonth === today.key && day === today.day;
									const weekend = isWeekend(activeMonth, day);
									const unnamed = habit.name.trim().length === 0;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: cn("p-0", isToday ? "bg-today" : weekend ? "bg-weekend/70" : ""),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											disabled: unnamed,
											"aria-pressed": on,
											"aria-label": `${habit.name || `Habit ${index + 1}`}, day ${day}${on ? ", complete" : ""}`,
											onClick: () => toggleCheck(habit.id, day),
											className: cn("flex size-9 items-center justify-center transition-[background-color,color] duration-150 disabled:cursor-not-allowed disabled:opacity-30", on ? "bg-accent text-accent-fg hover:bg-accent/90" : "hover:bg-accent-soft"),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
												className: cn("size-3.5 transition-[opacity,transform] duration-150", on ? "opacity-100 scale-100" : "opacity-0 scale-50"),
												strokeWidth: 3
											})
										})
									}, day);
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-2 text-right text-xs tabular-nums text-muted",
									children: habit.name.trim() ? done : "—"
								})
							]
						}, habit.id);
					}) })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3 px-4 py-3 sm:px-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-[0.14em] text-muted uppercase",
						children: "Sleep"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hidden text-xs text-subtle sm:block",
						children: "One mark per night"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
						className: "w-max min-w-full border-collapse text-sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: SLEEP_HOURS.map((hours) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									scope: "row",
									className: "sticky left-0 z-10 min-w-40 bg-surface px-3 py-0 text-left text-sm font-medium shadow-[1px_0_0_0_var(--color-border)]",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex h-10 items-center tabular-nums",
										children: [hours, " hrs"]
									})
								}),
								days.map((day) => {
									const on = sheet.sleep[String(day)] === hours;
									const isToday = activeMonth === today.key && day === today.day;
									const weekend = isWeekend(activeMonth, day);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: cn("p-0", isToday ? "bg-today" : weekend ? "bg-weekend/70" : ""),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-pressed": on,
											"aria-label": `${hours} hours on day ${day}`,
											onClick: () => setSleep(day, hours),
											className: cn("flex size-9 items-center justify-center transition-[background-color,color] duration-150", on ? "bg-accent text-accent-fg hover:bg-accent/90" : "hover:bg-accent-soft"),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2 rounded-full bg-accent-fg transition-opacity duration-150", on ? "opacity-100" : "opacity-0") })
										})
									}, day);
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { className: "min-w-12" })
							]
						}, hours)) })
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-border px-4 py-4 sm:px-5 sm:py-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-medium tracking-[0.14em] text-muted uppercase",
						children: "Notes"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: sheet.notes,
						onChange: (e) => setNotes(e.target.value),
						placeholder: "How the month felt, what to keep, what to drop.",
						className: "mt-2 min-h-28",
						rows: 4
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "no-print mt-3 flex justify-end",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "sm",
						onClick: clearMonth,
						children: "Clear this month"
					})
				})]
			})
		]
	});
}
var badgeVariants = cva("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium tracking-wide", {
	variants: { variant: {
		default: "bg-accent-soft text-accent",
		outline: "border border-border text-muted",
		solid: "bg-accent text-accent-fg"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
function elapsedDaysFor(key, dim) {
	const today = todayInfo();
	if (key < today.key) return dim;
	if (key > today.key) return 0;
	return Math.min(today.day, dim);
}
function habitDoneOnDay(sheet, habit, day) {
	return Boolean(sheet.checks[checkKey(habit.id, day)]);
}
function streakForHabit(sheet, habit, elapsed) {
	let streak = 0;
	for (let day = elapsed; day >= 1; day--) {
		if (!habitDoneOnDay(sheet, habit, day)) break;
		streak += 1;
	}
	return streak;
}
function streakFromDaily(daily, threshold = .8) {
	let current = 0;
	let best = 0;
	let run = 0;
	for (const d of daily) if (d.total > 0 && d.rate >= threshold) {
		run += 1;
		if (run > best) best = run;
	} else run = 0;
	for (let i = daily.length - 1; i >= 0; i--) {
		const d = daily[i];
		if (d && d.total > 0 && d.rate >= threshold) current += 1;
		else break;
	}
	return {
		current,
		best
	};
}
function computeMonthStats(key, sheet) {
	const dim = daysInMonthKey(key);
	const elapsed = elapsedDaysFor(key, dim);
	const habits = activeHabits(sheet);
	const today = todayInfo();
	const daily = [];
	for (let day = 1; day <= elapsed; day++) {
		const done = habits.reduce((n, h) => n + (habitDoneOnDay(sheet, h, day) ? 1 : 0), 0);
		const total = habits.length;
		daily.push({
			day,
			done,
			total,
			rate: total === 0 ? 0 : done / total
		});
	}
	let completedCells = 0;
	const possibleCells = habits.length * elapsed;
	const habitStats = habits.map((habit) => {
		let done = 0;
		for (let day = 1; day <= elapsed; day++) if (habitDoneOnDay(sheet, habit, day)) done += 1;
		completedCells += done;
		return {
			id: habit.id,
			name: habit.name,
			done,
			total: elapsed,
			rate: elapsed === 0 ? 0 : done / elapsed,
			streak: streakForHabit(sheet, habit, elapsed)
		};
	});
	const { current, best } = streakFromDaily(daily);
	const scored = daily.filter((d) => d.total > 0);
	const bestDay = scored.length === 0 ? null : scored.reduce((a, b) => b.rate > a.rate ? b : a);
	const worstDay = scored.length === 0 ? null : scored.reduce((a, b) => b.rate < a.rate ? b : a);
	const sleepDist = {
		5: 0,
		6: 0,
		7: 0,
		8: 0,
		9: 0
	};
	let sleepSum = 0;
	let sleepLogged = 0;
	for (let day = 1; day <= elapsed; day++) {
		const hours = sheet.sleep[String(day)];
		if (!hours) continue;
		sleepDist[hours] += 1;
		sleepSum += hours;
		sleepLogged += 1;
	}
	return {
		elapsedDays: elapsed,
		daysInMonth: dim,
		isCurrent: key === today.key,
		overallRate: possibleCells === 0 ? 0 : completedCells / possibleCells,
		completedCells,
		possibleCells,
		currentStreak: current,
		bestStreak: best,
		perfectDays: daily.filter((d) => d.total > 0 && d.rate === 1).length,
		bestDay,
		worstDay,
		habits: habitStats,
		daily,
		sleepAverage: sleepLogged === 0 ? null : sleepSum / sleepLogged,
		sleepLogged,
		sleepDist
	};
}
function formatPct(rate) {
	return `${Math.round(rate * 100)}%`;
}
function formatHours(value) {
	if (value === null || Number.isNaN(value)) return "—";
	return `${value.toFixed(1)}h`;
}
function ChartTooltip({ active, payload, label, suffix = "" }) {
	if (!active || !payload?.length) return null;
	const value = payload[0]?.value;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md bg-fg px-2.5 py-1.5 text-xs text-accent-fg shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-accent-fg/70",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-medium tabular-nums",
			children: typeof value === "number" && suffix === "%" ? formatPct(value / 100) : `${value ?? "—"}${suffix}`
		})]
	});
}
function StatCard({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-bg-warm px-4 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-wide text-muted uppercase",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-3xl font-medium tracking-tight tabular-nums text-fg",
				children: value
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-subtle",
				children: hint
			}) : null
		]
	});
}
function Ring({ rate }) {
	const r = 36;
	const c = 2 * Math.PI * r;
	const offset = c * (1 - Math.min(1, Math.max(0, rate)));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 88 88",
		className: "size-24",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "44",
			cy: "44",
			r,
			fill: "none",
			stroke: "var(--color-border)",
			strokeWidth: "8"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "44",
			cy: "44",
			r,
			fill: "none",
			stroke: "var(--color-accent)",
			strokeWidth: "8",
			strokeLinecap: "round",
			strokeDasharray: c,
			strokeDashoffset: offset,
			transform: "rotate(-90 44 44)"
		})]
	});
}
function MonthlyReport() {
	const activeMonth = useHabitStore((s) => s.activeMonth);
	const setView = useHabitStore((s) => s.setView);
	const sheet = useActiveSheet();
	const stats = (0, import_react.useMemo)(() => computeMonthStats(activeMonth, sheet), [activeMonth, sheet]);
	const dailyChart = stats.daily.map((d) => ({
		day: String(d.day),
		pct: Math.round(d.rate * 100)
	}));
	const sleepChart = SLEEP_HOURS.slice().reverse().map((hours) => ({
		hours: `${hours}h`,
		nights: stats.sleepDist[hours]
	}));
	const ranked = [...stats.habits].sort((a, b) => b.rate - a.rate);
	if (stats.habits.length === 0 || stats.elapsedDays === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl bg-surface px-5 py-10 text-center shadow-[var(--shadow-sheet)] sm:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-medium tracking-tight",
				children: "No report yet"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-2 max-w-md text-sm leading-normal text-muted",
				children: stats.habits.length === 0 ? "Name at least one habit on the sheet, then check off days to build a monthly report." : "This month has no elapsed days to score. Check back once the month begins, or flip to a past month."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-6",
				onClick: () => setView("sheet"),
				children: "Open the sheet"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl bg-surface p-5 shadow-[var(--shadow-sheet)] sm:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ring, { rate: stats.overallRate }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium tracking-wide text-muted uppercase",
								children: formatMonthLabel(activeMonth)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-3xl font-medium tracking-tight tabular-nums",
								children: formatPct(stats.overallRate)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted",
								children: [
									stats.completedCells,
									" of ",
									stats.possibleCells,
									" checks",
									stats.isCurrent ? " through today" : ""
								]
							})
						] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
						variant: "outline",
						className: "self-start",
						children: [
							stats.elapsedDays,
							" / ",
							stats.daysInMonth,
							" days scored"
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid grid-cols-2 gap-3 lg:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
							label: "Current streak",
							value: `${stats.currentStreak}d`,
							hint: "Days at 80%+ in a row"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
							label: "Best streak",
							value: `${stats.bestStreak}d`,
							hint: "Longest run this month"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
							label: "Perfect days",
							value: String(stats.perfectDays),
							hint: "Every named habit done"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
							label: "Sleep average",
							value: formatHours(stats.sleepAverage),
							hint: stats.sleepLogged ? `${stats.sleepLogged} nights logged` : "No nights logged"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl bg-surface p-5 shadow-[var(--shadow-sheet)] sm:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-xl font-medium tracking-tight",
						children: "Habit ranking"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-subtle",
						children: "Share of elapsed days"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 flex flex-col gap-3",
					children: ranked.map((habit, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "min-w-0 truncate text-sm font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mr-2 text-subtle tabular-nums",
								children: String(i + 1).padStart(2, "0")
							}), habit.name]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "shrink-0 text-sm tabular-nums text-muted",
							children: [
								habit.done,
								"/",
								habit.total,
								" · ",
								formatPct(habit.rate),
								habit.streak > 0 ? ` · ${habit.streak}d` : ""
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1.5 h-2 overflow-hidden rounded-full bg-bg-warm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full rounded-full bg-accent transition-[width] duration-300 ease-out",
							style: { width: `${Math.round(habit.rate * 100)}%` }
						})
					})] }, habit.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl bg-surface p-5 shadow-[var(--shadow-sheet)] sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-xl font-medium tracking-tight",
						children: "Daily rhythm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Percent of named habits completed each day."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 h-52 w-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
								data: dailyChart,
								margin: {
									top: 8,
									right: 8,
									left: -18,
									bottom: 0
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
										id: "fillRate",
										x1: "0",
										y1: "0",
										x2: "0",
										y2: "1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
											offset: "0%",
											stopColor: "var(--color-accent)",
											stopOpacity: .28
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
											offset: "100%",
											stopColor: "var(--color-accent)",
											stopOpacity: .02
										})]
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
										stroke: "var(--color-border)",
										vertical: false,
										strokeDasharray: "3 6"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "day",
										tick: {
											fill: "var(--color-muted)",
											fontSize: 11
										},
										tickLine: false,
										axisLine: false,
										interval: "preserveStartEnd"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										domain: [0, 100],
										tick: {
											fill: "var(--color-muted)",
											fontSize: 11
										},
										tickLine: false,
										axisLine: false,
										tickFormatter: (v) => `${v}`
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
										content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTooltip, { suffix: "%" }),
										cursor: { stroke: "var(--color-border-strong)" }
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
										type: "monotone",
										dataKey: "pct",
										stroke: "var(--color-accent)",
										strokeWidth: 2,
										fill: "url(#fillRate)",
										name: "Completion"
									})
								]
							})
						})
					}),
					stats.bestDay && stats.worstDay ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm text-muted",
						children: [
							"Strongest day ",
							stats.bestDay.day,
							" (",
							formatPct(stats.bestDay.rate),
							"). Lightest day ",
							stats.worstDay.day,
							" (",
							formatPct(stats.worstDay.rate),
							")."
						]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl bg-surface p-5 shadow-[var(--shadow-sheet)] sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-xl font-medium tracking-tight",
						children: "Sleep"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Nights logged at each duration."
					}),
					stats.sleepLogged === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-sm text-subtle",
						children: "Mark sleep on the sheet to see the distribution here."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 h-44 w-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
								data: sleepChart,
								margin: {
									top: 8,
									right: 8,
									left: -18,
									bottom: 0
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
										stroke: "var(--color-border)",
										vertical: false,
										strokeDasharray: "3 6"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "hours",
										tick: {
											fill: "var(--color-muted)",
											fontSize: 11
										},
										tickLine: false,
										axisLine: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										allowDecimals: false,
										tick: {
											fill: "var(--color-muted)",
											fontSize: 11
										},
										tickLine: false,
										axisLine: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
										content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTooltip, { suffix: " nights" }),
										cursor: { fill: "var(--color-bg-warm)" }
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "nights",
										fill: "var(--color-accent)",
										radius: [
											6,
											6,
											0,
											0
										],
										name: "Nights"
									})
								]
							})
						})
					})
				]
			}),
			sheet.notes.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl bg-surface p-5 shadow-[var(--shadow-sheet)] sm:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-xl font-medium tracking-tight",
					children: "Notes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 whitespace-pre-wrap text-sm leading-normal text-fg",
					children: sheet.notes
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("pb-2 text-center text-xs text-subtle"),
				children: "Figures use elapsed days only — future dates are not scored."
			})
		]
	});
}
function TodayPanel() {
	const activeMonth = useHabitStore((s) => s.activeMonth);
	const toggleCheck = useHabitStore((s) => s.toggleCheck);
	const setSleep = useHabitStore((s) => s.setSleep);
	const sheet = useActiveSheet();
	const today = todayInfo();
	if (activeMonth !== today.key) return null;
	const habits = activeHabits(sheet);
	const sleep = sheet.sleep[String(today.day)] ?? null;
	const done = habits.filter((h) => sheet.checks[checkKey(h.id, today.day)]).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "no-print rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg font-medium tracking-tight",
					children: "Today"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted tabular-nums",
					children: [
						formatMonthShort(activeMonth),
						" ",
						today.day,
						habits.length > 0 ? ` · ${done}/${habits.length}` : ""
					]
				})]
			}),
			habits.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "Name a habit on the sheet to start checking in."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2",
				children: habits.map((habit) => {
					const on = Boolean(sheet.checks[checkKey(habit.id, today.day)]);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => toggleCheck(habit.id, today.day),
						"aria-pressed": on,
						className: cn("flex min-h-11 w-full items-center gap-3 rounded-xl px-3 py-2 text-left transition-[background-color,color,box-shadow] duration-150", on ? "bg-accent text-accent-fg" : "bg-bg-warm text-fg hover:bg-weekend"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("flex size-5 shrink-0 items-center justify-center rounded-xs border", on ? "border-accent-fg/40 bg-accent-fg/15" : "border-border-strong bg-surface-raised"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
								className: cn("size-3.5 transition-[opacity,transform] duration-150", on ? "opacity-100 scale-100" : "opacity-0 scale-50"),
								strokeWidth: 3
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate text-sm font-medium",
							children: habit.name
						})]
					}) }, habit.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted uppercase",
					children: "Sleep last night"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 flex flex-wrap gap-2",
					children: SLEEP_HOURS.map((hours) => {
						const on = sleep === hours;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setSleep(today.day, hours),
							"aria-pressed": on,
							className: cn("min-h-11 min-w-14 rounded-full px-3 text-sm font-medium tabular-nums transition-[background-color,color] duration-150", on ? "bg-accent text-accent-fg" : "bg-bg-warm text-fg hover:bg-weekend"),
							children: [hours, "h"]
						}, hours);
					})
				})]
			})
		]
	});
}
function Home() {
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const view = useHabitStore((s) => s.view);
	(0, import_react.useEffect)(() => {
		const persistApi = useHabitStore.persist;
		const done = () => setHydrated(true);
		if (!persistApi?.rehydrate) {
			done();
			return;
		}
		Promise.resolve(persistApi.rehydrate()).finally(done);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-svh bg-bg px-4 py-6 sm:px-6 sm:py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto flex w-full max-w-6xl flex-col gap-6",
			children: hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {}), view === "sheet" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TodayPanel, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HabitSheet, {})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MonthlyReport, {})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppSkeleton, {})
		})
	});
}
function AppSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		"aria-busy": "true",
		"aria-live": "polite",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-[0.18em] text-muted uppercase",
				children: "Small habits. Big change."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-3xl font-semibold tracking-tight text-fg sm:text-4xl",
				children: "Habit ledger"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Opening this month’s sheet…"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-72 rounded-2xl bg-surface shadow-[var(--shadow-border)]" })
		]
	});
}
//#endregion
export { Home as component };
