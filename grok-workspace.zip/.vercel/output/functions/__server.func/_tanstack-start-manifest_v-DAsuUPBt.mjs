//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DAsuUPBt.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index--bui4f0s.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index--bui4f0s.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BdOS7Rch.js"]
	}
} });
//#endregion
export { tsrStartManifest };
