export type SleepHours = 5 | 6 | 7 | 8 | 9;

export const SLEEP_HOURS: SleepHours[] = [9, 8, 7, 6, 5];

export type Habit = {
  id: string;
  name: string;
};

export type MonthSheet = {
  personName: string;
  habits: Habit[];
  checks: Record<string, boolean>;
  sleep: Record<string, SleepHours>;
  notes: string;
};

export const HABIT_COUNT = 10;

export const DEFAULT_HABIT_NAMES = [
  "Wake by 6:30",
  "Make the bed",
  "Drink 3L water",
  "Train",
  "Read 20 min",
  "No added sugar",
  "Walk 8k steps",
  "Stretch",
  "Journal",
  "Phone away by 10",
] as const;

export function defaultHabits(): Habit[] {
  return DEFAULT_HABIT_NAMES.map((name, i) => ({
    id: `h${i + 1}`,
    name,
  }));
}

export function checkKey(habitId: string, day: number) {
  return `${habitId}:${day}`;
}

export function monthKey(date: Date = new Date()): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  return `${y}-${m}`;
}

export function parseMonthKey(key: string): { year: number; month: number } {
  const [ys, ms] = key.split("-");
  return { year: Number(ys), month: Number(ms) };
}

export function daysInMonthKey(key: string): number {
  const { year, month } = parseMonthKey(key);
  return new Date(year, month, 0).getDate();
}

export function shiftMonth(key: string, delta: number): string {
  const { year, month } = parseMonthKey(key);
  return monthKey(new Date(year, month - 1 + delta, 1));
}

export function formatMonthLabel(key: string): string {
  const { year, month } = parseMonthKey(key);
  return new Date(year, month - 1, 1).toLocaleDateString("en-US", {
    month: "long",
    year: "numeric",
  });
}

export function formatMonthShort(key: string): string {
  const { year, month } = parseMonthKey(key);
  return new Date(year, month - 1, 1).toLocaleDateString("en-US", {
    month: "short",
    year: "numeric",
  });
}

export function weekday(key: string, day: number): number {
  const { year, month } = parseMonthKey(key);
  return new Date(year, month - 1, day).getDay();
}

export function isWeekend(key: string, day: number): boolean {
  const wd = weekday(key, day);
  return wd === 0 || wd === 6;
}

export function weekdayLetter(key: string, day: number): string {
  const names = ["S", "M", "T", "W", "T", "F", "S"];
  return names[weekday(key, day)] ?? "";
}

export function todayInfo() {
  const now = new Date();
  return { key: monthKey(now), day: now.getDate() };
}

export function emptySheet(
  personName = "",
  habits: Habit[] = defaultHabits(),
): MonthSheet {
  return {
    personName,
    habits: habits.map((h) => ({ ...h })),
    checks: {},
    sleep: {},
    notes: "",
  };
}

export function activeHabits(sheet: MonthSheet): Habit[] {
  return sheet.habits.filter((h) => h.name.trim().length > 0);
}

export function seedSheet(key: string): MonthSheet {
  const sheet = emptySheet();
  const dim = daysInMonthKey(key);
  const today = todayInfo();
  const lastElapsed = key < today.key ? dim : key === today.key ? today.day : 0;
  const fillUntil = Math.max(0, lastElapsed - (key === today.key ? 1 : 0));

  const rates = [0.92, 0.78, 0.86, 0.64, 0.72, 0.7, 0.58, 0.68, 0.54, 0.88];
  for (let hi = 0; hi < HABIT_COUNT; hi++) {
    const habit = sheet.habits[hi];
    if (!habit) continue;
    const rate = rates[hi] ?? 0.7;
    for (let day = 1; day <= fillUntil; day++) {
      const n = (hi * 31 + day * 17 + 7) % 100;
      if (n < rate * 100) {
        sheet.checks[checkKey(habit.id, day)] = true;
      }
    }
  }

  const sleepCycle: SleepHours[] = [7, 8, 7, 8, 6, 9, 8];
  for (let day = 1; day <= fillUntil; day++) {
    sheet.sleep[String(day)] = sleepCycle[(day - 1) % 7] ?? 7;
  }

  if (key === today.key && fillUntil > 0) {
    sheet.notes =
      "Training felt strong this week. Keep water and bedtime consistent — sleep dipped midweek.";
  }

  return sheet;
}
