import {
  type Habit,
  type MonthSheet,
  type SleepHours,
  SLEEP_HOURS,
  activeHabits,
  checkKey,
  daysInMonthKey,
  todayInfo,
} from "./model";

export type HabitStat = {
  id: string;
  name: string;
  done: number;
  total: number;
  rate: number;
  streak: number;
};

export type DayRate = {
  day: number;
  done: number;
  total: number;
  rate: number;
};

export type MonthStats = {
  elapsedDays: number;
  daysInMonth: number;
  isCurrent: boolean;
  overallRate: number;
  completedCells: number;
  possibleCells: number;
  currentStreak: number;
  bestStreak: number;
  perfectDays: number;
  bestDay: DayRate | null;
  worstDay: DayRate | null;
  habits: HabitStat[];
  daily: DayRate[];
  sleepAverage: number | null;
  sleepLogged: number;
  sleepDist: Record<SleepHours, number>;
};

function elapsedDaysFor(key: string, dim: number): number {
  const today = todayInfo();
  if (key < today.key) return dim;
  if (key > today.key) return 0;
  return Math.min(today.day, dim);
}

function habitDoneOnDay(sheet: MonthSheet, habit: Habit, day: number) {
  return Boolean(sheet.checks[checkKey(habit.id, day)]);
}

function streakForHabit(
  sheet: MonthSheet,
  habit: Habit,
  elapsed: number,
): number {
  let streak = 0;
  for (let day = elapsed; day >= 1; day--) {
    if (!habitDoneOnDay(sheet, habit, day)) break;
    streak += 1;
  }
  return streak;
}

function streakFromDaily(daily: DayRate[], threshold = 0.8): {
  current: number;
  best: number;
} {
  let current = 0;
  let best = 0;
  let run = 0;
  for (const d of daily) {
    if (d.total > 0 && d.rate >= threshold) {
      run += 1;
      if (run > best) best = run;
    } else {
      run = 0;
    }
  }
  for (let i = daily.length - 1; i >= 0; i--) {
    const d = daily[i];
    if (d && d.total > 0 && d.rate >= threshold) current += 1;
    else break;
  }
  return { current, best };
}

export function computeMonthStats(key: string, sheet: MonthSheet): MonthStats {
  const dim = daysInMonthKey(key);
  const elapsed = elapsedDaysFor(key, dim);
  const habits = activeHabits(sheet);
  const today = todayInfo();

  const daily: DayRate[] = [];
  for (let day = 1; day <= elapsed; day++) {
    const done = habits.reduce(
      (n, h) => n + (habitDoneOnDay(sheet, h, day) ? 1 : 0),
      0,
    );
    const total = habits.length;
    daily.push({
      day,
      done,
      total,
      rate: total === 0 ? 0 : done / total,
    });
  }

  let completedCells = 0;
  const possibleCells = habits.length * elapsed;
  const habitStats: HabitStat[] = habits.map((habit) => {
    let done = 0;
    for (let day = 1; day <= elapsed; day++) {
      if (habitDoneOnDay(sheet, habit, day)) done += 1;
    }
    completedCells += done;
    return {
      id: habit.id,
      name: habit.name,
      done,
      total: elapsed,
      rate: elapsed === 0 ? 0 : done / elapsed,
      streak: streakForHabit(sheet, habit, elapsed),
    };
  });

  const { current, best } = streakFromDaily(daily);
  const scored = daily.filter((d) => d.total > 0);
  const bestDay =
    scored.length === 0
      ? null
      : scored.reduce((a, b) => (b.rate > a.rate ? b : a));
  const worstDay =
    scored.length === 0
      ? null
      : scored.reduce((a, b) => (b.rate < a.rate ? b : a));

  const sleepDist: Record<SleepHours, number> = { 5: 0, 6: 0, 7: 0, 8: 0, 9: 0 };
  let sleepSum = 0;
  let sleepLogged = 0;
  for (let day = 1; day <= elapsed; day++) {
    const hours = sheet.sleep[String(day)];
    if (!hours) continue;
    sleepDist[hours] += 1;
    sleepSum += hours;
    sleepLogged += 1;
  }

  return {
    elapsedDays: elapsed,
    daysInMonth: dim,
    isCurrent: key === today.key,
    overallRate: possibleCells === 0 ? 0 : completedCells / possibleCells,
    completedCells,
    possibleCells,
    currentStreak: current,
    bestStreak: best,
    perfectDays: daily.filter((d) => d.total > 0 && d.rate === 1).length,
    bestDay,
    worstDay,
    habits: habitStats,
    daily,
    sleepAverage: sleepLogged === 0 ? null : sleepSum / sleepLogged,
    sleepLogged,
    sleepDist,
  };
}

export function sleepHoursList(): SleepHours[] {
  return SLEEP_HOURS;
}

export function formatPct(rate: number): string {
  return `${Math.round(rate * 100)}%`;
}

export function formatHours(value: number | null): string {
  if (value === null || Number.isNaN(value)) return "—";
  return `${value.toFixed(1)}h`;
}
