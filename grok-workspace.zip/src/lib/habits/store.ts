import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  type MonthSheet,
  type SleepHours,
  emptySheet,
  monthKey,
  seedSheet,
  shiftMonth,
} from "./model";

type HabitState = {
  months: Record<string, MonthSheet>;
  activeMonth: string;
  view: "sheet" | "report";
  setView: (view: "sheet" | "report") => void;
  setActiveMonth: (key: string) => void;
  stepMonth: (delta: number) => void;
  setPersonName: (name: string) => void;
  setHabitName: (habitId: string, name: string) => void;
  toggleCheck: (habitId: string, day: number) => void;
  setSleep: (day: number, hours: SleepHours | null) => void;
  setNotes: (notes: string) => void;
  clearMonth: () => void;
  resetToDefaults: () => void;
};

function latestHabitsAndName(months: Record<string, MonthSheet>): {
  personName: string;
  habits: MonthSheet["habits"];
} {
  const keys = Object.keys(months).sort();
  const last = keys.at(-1);
  if (!last) return { personName: "", habits: emptySheet().habits };
  const sheet = months[last];
  if (!sheet) return { personName: "", habits: emptySheet().habits };
  return { personName: sheet.personName, habits: sheet.habits };
}

function ensureMonth(
  months: Record<string, MonthSheet>,
  key: string,
): Record<string, MonthSheet> {
  if (months[key]) return months;
  const { personName, habits } = latestHabitsAndName(months);
  return { ...months, [key]: emptySheet(personName, habits) };
}

const initialKey = monthKey();

export const useHabitStore = create<HabitState>()(
  persist(
    (set, get) => ({
      months: { [initialKey]: seedSheet(initialKey) },
      activeMonth: initialKey,
      view: "sheet",
      setView: (view) => set({ view }),
      setActiveMonth: (key) => {
        const months = ensureMonth(get().months, key);
        set({ months, activeMonth: key });
      },
      stepMonth: (delta) => {
        const next = shiftMonth(get().activeMonth, delta);
        const months = ensureMonth(get().months, next);
        set({ months, activeMonth: next });
      },
      setPersonName: (name) => {
        const { activeMonth, months } = get();
        const sheet = months[activeMonth];
        if (!sheet) return;
        set({
          months: {
            ...months,
            [activeMonth]: { ...sheet, personName: name },
          },
        });
      },
      setHabitName: (habitId, name) => {
        const { activeMonth, months } = get();
        const sheet = months[activeMonth];
        if (!sheet) return;
        set({
          months: {
            ...months,
            [activeMonth]: {
              ...sheet,
              habits: sheet.habits.map((h) =>
                h.id === habitId ? { ...h, name } : h,
              ),
            },
          },
        });
      },
      toggleCheck: (habitId, day) => {
        const { activeMonth, months } = get();
        const sheet = months[activeMonth];
        if (!sheet) return;
        const key = `${habitId}:${day}`;
        const next = { ...sheet.checks };
        if (next[key]) delete next[key];
        else next[key] = true;
        set({
          months: {
            ...months,
            [activeMonth]: { ...sheet, checks: next },
          },
        });
      },
      setSleep: (day, hours) => {
        const { activeMonth, months } = get();
        const sheet = months[activeMonth];
        if (!sheet) return;
        const next = { ...sheet.sleep };
        const k = String(day);
        if (hours === null || next[k] === hours) delete next[k];
        else next[k] = hours;
        set({
          months: {
            ...months,
            [activeMonth]: { ...sheet, sleep: next },
          },
        });
      },
      setNotes: (notes) => {
        const { activeMonth, months } = get();
        const sheet = months[activeMonth];
        if (!sheet) return;
        set({
          months: {
            ...months,
            [activeMonth]: { ...sheet, notes },
          },
        });
      },
      clearMonth: () => {
        const { activeMonth, months } = get();
        const sheet = months[activeMonth];
        if (!sheet) return;
        set({
          months: {
            ...months,
            [activeMonth]: {
              ...sheet,
              checks: {},
              sleep: {},
              notes: "",
            },
          },
        });
      },
      resetToDefaults: () => {
        const key = monthKey();
        set({
          months: { [key]: seedSheet(key) },
          activeMonth: key,
          view: "sheet",
        });
      },
    }),
    {
      name: "small-habits.v1",
      skipHydration: true,
      storage: {
        getItem: (name) => {
          try {
            if (typeof window === "undefined") return null;
            const raw = window.localStorage.getItem(name);
            return raw ? (JSON.parse(raw) as { state: unknown; version?: number }) : null;
          } catch {
            return null;
          }
        },
        setItem: (name, value) => {
          try {
            if (typeof window === "undefined") return;
            window.localStorage.setItem(name, JSON.stringify(value));
          } catch {
            /* ignore quota / privacy mode */
          }
        },
        removeItem: (name) => {
          try {
            if (typeof window === "undefined") return;
            window.localStorage.removeItem(name);
          } catch {
            /* ignore */
          }
        },
      },
      partialize: (state) => ({
        months: state.months,
        activeMonth: state.activeMonth,
      }),
    },
  ),
);

export function useActiveSheet(): MonthSheet {
  return useHabitStore((s) => {
    const sheet = s.months[s.activeMonth];
    return sheet ?? emptySheet();
  });
}
