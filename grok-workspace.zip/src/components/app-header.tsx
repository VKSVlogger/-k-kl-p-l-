import { ChevronLeft, ChevronRight, ClipboardList, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { formatMonthLabel } from "@/lib/habits/model";
import { useActiveSheet, useHabitStore } from "@/lib/habits/store";

export function AppHeader() {
  const activeMonth = useHabitStore((s) => s.activeMonth);
  const view = useHabitStore((s) => s.view);
  const stepMonth = useHabitStore((s) => s.stepMonth);
  const setView = useHabitStore((s) => s.setView);
  const setPersonName = useHabitStore((s) => s.setPersonName);
  const sheet = useActiveSheet();

  return (
    <header className="flex flex-col gap-5">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="min-w-0">
          <p className="text-xs font-medium tracking-[0.18em] text-muted uppercase">
            Small habits. Big change.
          </p>
          <h1 className="mt-1 font-display text-3xl font-semibold tracking-tight text-fg sm:text-4xl">
            Habit ledger
          </h1>
        </div>
        <div
          className="no-print grid grid-cols-2 rounded-full bg-bg-warm p-1 self-start sm:self-auto"
          role="tablist"
          aria-label="View"
        >
          <button
            type="button"
            role="tab"
            aria-selected={view === "sheet"}
            onClick={() => setView("sheet")}
            className={cn(
              "inline-flex h-9 items-center justify-center gap-1.5 rounded-full px-4 text-sm font-medium transition-[background-color,color,box-shadow] duration-150",
              view === "sheet"
                ? "bg-surface text-fg shadow-[var(--shadow-border)]"
                : "text-muted hover:text-fg",
            )}
          >
            <ClipboardList className="size-3.5" />
            Sheet
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={view === "report"}
            onClick={() => setView("report")}
            className={cn(
              "inline-flex h-9 items-center justify-center gap-1.5 rounded-full px-4 text-sm font-medium transition-[background-color,color,box-shadow] duration-150",
              view === "report"
                ? "bg-surface text-fg shadow-[var(--shadow-border)]"
                : "text-muted hover:text-fg",
            )}
          >
            <BarChart3 className="size-3.5" />
            Report
          </button>
        </div>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="no-print size-11"
            onClick={() => stepMonth(-1)}
            aria-label="Previous month"
          >
            <ChevronLeft className="size-5" />
          </Button>
          <p className="min-w-40 text-center font-display text-xl font-medium tracking-tight tabular-nums">
            {formatMonthLabel(activeMonth)}
          </p>
          <Button
            variant="ghost"
            size="icon"
            className="no-print size-11"
            onClick={() => stepMonth(1)}
            aria-label="Next month"
          >
            <ChevronRight className="size-5" />
          </Button>
        </div>

        <label className="flex min-w-0 items-center gap-2 sm:max-w-xs">
          <span className="shrink-0 text-xs font-medium tracking-wide text-muted uppercase">
            Name
          </span>
          <Input
            value={sheet.personName}
            onChange={(e) => setPersonName(e.target.value)}
            placeholder="Your name"
            aria-label="Your name"
            className="h-11 bg-surface-raised"
          />
        </label>
      </div>
    </header>
  );
}
