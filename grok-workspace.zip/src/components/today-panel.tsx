import { Check } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  SLEEP_HOURS,
  activeHabits,
  checkKey,
  formatMonthShort,
  todayInfo,
} from "@/lib/habits/model";
import { useActiveSheet, useHabitStore } from "@/lib/habits/store";

export function TodayPanel() {
  const activeMonth = useHabitStore((s) => s.activeMonth);
  const toggleCheck = useHabitStore((s) => s.toggleCheck);
  const setSleep = useHabitStore((s) => s.setSleep);
  const sheet = useActiveSheet();
  const today = todayInfo();

  if (activeMonth !== today.key) return null;

  const habits = activeHabits(sheet);
  const sleep = sheet.sleep[String(today.day)] ?? null;
  const done = habits.filter((h) => sheet.checks[checkKey(h.id, today.day)])
    .length;

  return (
    <section className="no-print rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5 lg:hidden">
      <div className="flex items-baseline justify-between gap-3">
        <h2 className="font-display text-lg font-medium tracking-tight">
          Today
        </h2>
        <p className="text-sm text-muted tabular-nums">
          {formatMonthShort(activeMonth)} {today.day}
          {habits.length > 0 ? ` · ${done}/${habits.length}` : ""}
        </p>
      </div>

      {habits.length === 0 ? (
        <p className="mt-3 text-sm text-muted">
          Name a habit on the sheet to start checking in.
        </p>
      ) : (
        <ul className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
          {habits.map((habit) => {
            const on = Boolean(sheet.checks[checkKey(habit.id, today.day)]);
            return (
              <li key={habit.id}>
                <button
                  type="button"
                  onClick={() => toggleCheck(habit.id, today.day)}
                  aria-pressed={on}
                  className={cn(
                    "flex min-h-11 w-full items-center gap-3 rounded-xl px-3 py-2 text-left transition-[background-color,color,box-shadow] duration-150",
                    on
                      ? "bg-accent text-accent-fg"
                      : "bg-bg-warm text-fg hover:bg-weekend",
                  )}
                >
                  <span
                    className={cn(
                      "flex size-5 shrink-0 items-center justify-center rounded-xs border",
                      on
                        ? "border-accent-fg/40 bg-accent-fg/15"
                        : "border-border-strong bg-surface-raised",
                    )}
                  >
                    <Check
                      className={cn(
                        "size-3.5 transition-[opacity,transform] duration-150",
                        on ? "opacity-100 scale-100" : "opacity-0 scale-50",
                      )}
                      strokeWidth={3}
                    />
                  </span>
                  <span className="truncate text-sm font-medium">
                    {habit.name}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      )}

      <div className="mt-4">
        <p className="text-xs font-medium tracking-wide text-muted uppercase">
          Sleep last night
        </p>
        <div className="mt-2 flex flex-wrap gap-2">
          {SLEEP_HOURS.map((hours) => {
            const on = sleep === hours;
            return (
              <button
                key={hours}
                type="button"
                onClick={() => setSleep(today.day, hours)}
                aria-pressed={on}
                className={cn(
                  "min-h-11 min-w-14 rounded-full px-3 text-sm font-medium tabular-nums transition-[background-color,color] duration-150",
                  on
                    ? "bg-accent text-accent-fg"
                    : "bg-bg-warm text-fg hover:bg-weekend",
                )}
              >
                {hours}h
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
