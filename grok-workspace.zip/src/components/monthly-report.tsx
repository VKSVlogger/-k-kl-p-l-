import { useMemo } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { formatMonthLabel, SLEEP_HOURS } from "@/lib/habits/model";
import { computeMonthStats, formatHours, formatPct } from "@/lib/habits/stats";
import { useActiveSheet, useHabitStore } from "@/lib/habits/store";

function ChartTooltip({
  active,
  payload,
  label,
  suffix = "",
}: {
  active?: boolean;
  payload?: Array<{ value?: number; name?: string }>;
  label?: string | number;
  suffix?: string;
}) {
  if (!active || !payload?.length) return null;
  const value = payload[0]?.value;
  return (
    <div className="rounded-md bg-fg px-2.5 py-1.5 text-xs text-accent-fg shadow-[var(--shadow-border)]">
      <p className="text-accent-fg/70">{label}</p>
      <p className="font-medium tabular-nums">
        {typeof value === "number" && suffix === "%"
          ? formatPct(value / 100)
          : `${value ?? "—"}${suffix}`}
      </p>
    </div>
  );
}

function StatCard({
  label,
  value,
  hint,
}: {
  label: string;
  value: string;
  hint?: string;
}) {
  return (
    <div className="rounded-xl bg-bg-warm px-4 py-4">
      <p className="text-xs font-medium tracking-wide text-muted uppercase">
        {label}
      </p>
      <p className="mt-1 font-display text-3xl font-medium tracking-tight tabular-nums text-fg">
        {value}
      </p>
      {hint ? <p className="mt-1 text-xs text-subtle">{hint}</p> : null}
    </div>
  );
}

function Ring({ rate }: { rate: number }) {
  const r = 36;
  const c = 2 * Math.PI * r;
  const offset = c * (1 - Math.min(1, Math.max(0, rate)));
  return (
    <svg
      viewBox="0 0 88 88"
      className="size-24"
      aria-hidden="true"
    >
      <circle
        cx="44"
        cy="44"
        r={r}
        fill="none"
        stroke="var(--color-border)"
        strokeWidth="8"
      />
      <circle
        cx="44"
        cy="44"
        r={r}
        fill="none"
        stroke="var(--color-accent)"
        strokeWidth="8"
        strokeLinecap="round"
        strokeDasharray={c}
        strokeDashoffset={offset}
        transform="rotate(-90 44 44)"
      />
    </svg>
  );
}

export function MonthlyReport() {
  const activeMonth = useHabitStore((s) => s.activeMonth);
  const setView = useHabitStore((s) => s.setView);
  const sheet = useActiveSheet();
  const stats = useMemo(
    () => computeMonthStats(activeMonth, sheet),
    [activeMonth, sheet],
  );

  const dailyChart = stats.daily.map((d) => ({
    day: String(d.day),
    pct: Math.round(d.rate * 100),
  }));

  const sleepChart = SLEEP_HOURS.slice()
    .reverse()
    .map((hours) => ({
      hours: `${hours}h`,
      nights: stats.sleepDist[hours],
    }));

  const ranked = [...stats.habits].sort((a, b) => b.rate - a.rate);

  if (stats.habits.length === 0 || stats.elapsedDays === 0) {
    return (
      <section className="rounded-2xl bg-surface px-5 py-10 text-center shadow-[var(--shadow-sheet)] sm:px-8">
        <h2 className="font-display text-2xl font-medium tracking-tight">
          No report yet
        </h2>
        <p className="mx-auto mt-2 max-w-md text-sm leading-normal text-muted">
          {stats.habits.length === 0
            ? "Name at least one habit on the sheet, then check off days to build a monthly report."
            : "This month has no elapsed days to score. Check back once the month begins, or flip to a past month."}
        </p>
        <Button className="mt-6" onClick={() => setView("sheet")}>
          Open the sheet
        </Button>
      </section>
    );
  }

  return (
    <div className="flex flex-col gap-5">
      <section className="rounded-2xl bg-surface p-5 shadow-[var(--shadow-sheet)] sm:p-6">
        <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-4">
            <Ring rate={stats.overallRate} />
            <div>
              <p className="text-xs font-medium tracking-wide text-muted uppercase">
                {formatMonthLabel(activeMonth)}
              </p>
              <h2 className="font-display text-3xl font-medium tracking-tight tabular-nums">
                {formatPct(stats.overallRate)}
              </h2>
              <p className="mt-1 text-sm text-muted">
                {stats.completedCells} of {stats.possibleCells} checks
                {stats.isCurrent ? " through today" : ""}
              </p>
            </div>
          </div>
          <Badge variant="outline" className="self-start">
            {stats.elapsedDays} / {stats.daysInMonth} days scored
          </Badge>
        </div>

        <div className="mt-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
          <StatCard
            label="Current streak"
            value={`${stats.currentStreak}d`}
            hint="Days at 80%+ in a row"
          />
          <StatCard
            label="Best streak"
            value={`${stats.bestStreak}d`}
            hint="Longest run this month"
          />
          <StatCard
            label="Perfect days"
            value={String(stats.perfectDays)}
            hint="Every named habit done"
          />
          <StatCard
            label="Sleep average"
            value={formatHours(stats.sleepAverage)}
            hint={
              stats.sleepLogged
                ? `${stats.sleepLogged} nights logged`
                : "No nights logged"
            }
          />
        </div>
      </section>

      <section className="rounded-2xl bg-surface p-5 shadow-[var(--shadow-sheet)] sm:p-6">
        <div className="flex items-baseline justify-between gap-3">
          <h3 className="font-display text-xl font-medium tracking-tight">
            Habit ranking
          </h3>
          <p className="text-xs text-subtle">Share of elapsed days</p>
        </div>
        <ul className="mt-4 flex flex-col gap-3">
          {ranked.map((habit, i) => (
            <li key={habit.id}>
              <div className="flex items-baseline justify-between gap-3">
                <div className="flex min-w-0 items-baseline gap-2">
                  <span className="shrink-0 text-sm tabular-nums text-subtle">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <p className="min-w-0 truncate text-sm font-medium">
                    {habit.name}
                  </p>
                </div>
                <p className="shrink-0 text-sm tabular-nums text-muted">
                  {habit.done}/{habit.total} · {formatPct(habit.rate)}
                  {habit.streak > 0 ? ` · ${habit.streak}d` : ""}
                </p>
              </div>
              <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-bg-warm">
                <div
                  className="h-full rounded-full bg-accent transition-[width] duration-300 ease-out"
                  style={{ width: `${Math.round(habit.rate * 100)}%` }}
                />
              </div>
            </li>
          ))}
        </ul>
      </section>

      <section className="rounded-2xl bg-surface p-5 shadow-[var(--shadow-sheet)] sm:p-6">
        <h3 className="font-display text-xl font-medium tracking-tight">
          Daily rhythm
        </h3>
        <p className="mt-1 text-sm text-muted">
          Percent of named habits completed each day.
        </p>
        <div className="mt-4 h-52 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={dailyChart} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
              <defs>
                <linearGradient id="fillRate" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--color-accent)" stopOpacity={0.28} />
                  <stop offset="100%" stopColor="var(--color-accent)" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid
                stroke="var(--color-border)"
                vertical={false}
                strokeDasharray="3 6"
              />
              <XAxis
                dataKey="day"
                tick={{ fill: "var(--color-muted)", fontSize: 11 }}
                tickLine={false}
                axisLine={false}
                interval="preserveStartEnd"
              />
              <YAxis
                domain={[0, 100]}
                tick={{ fill: "var(--color-muted)", fontSize: 11 }}
                tickLine={false}
                axisLine={false}
                tickFormatter={(v) => `${v}`}
              />
              <Tooltip
                content={<ChartTooltip suffix="%" />}
                cursor={{ stroke: "var(--color-border-strong)" }}
              />
              <Area
                type="monotone"
                dataKey="pct"
                stroke="var(--color-accent)"
                strokeWidth={2}
                fill="url(#fillRate)"
                name="Completion"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        {stats.bestDay && stats.worstDay ? (
          <p className="mt-3 text-sm text-muted">
            Strongest day {stats.bestDay.day} ({formatPct(stats.bestDay.rate)}).
            Lightest day {stats.worstDay.day} ({formatPct(stats.worstDay.rate)}).
          </p>
        ) : null}
      </section>

      <section className="rounded-2xl bg-surface p-5 shadow-[var(--shadow-sheet)] sm:p-6">
        <h3 className="font-display text-xl font-medium tracking-tight">
          Sleep
        </h3>
        <p className="mt-1 text-sm text-muted">
          Nights logged at each duration.
        </p>
        {stats.sleepLogged === 0 ? (
          <p className="mt-6 text-sm text-subtle">
            Mark sleep on the sheet to see the distribution here.
          </p>
        ) : (
          <div className="mt-4 h-44 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={sleepChart} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                <CartesianGrid
                  stroke="var(--color-border)"
                  vertical={false}
                  strokeDasharray="3 6"
                />
                <XAxis
                  dataKey="hours"
                  tick={{ fill: "var(--color-muted)", fontSize: 11 }}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  allowDecimals={false}
                  tick={{ fill: "var(--color-muted)", fontSize: 11 }}
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip
                  content={<ChartTooltip suffix=" nights" />}
                  cursor={{ fill: "var(--color-bg-warm)" }}
                />
                <Bar
                  dataKey="nights"
                  fill="var(--color-accent)"
                  radius={[6, 6, 0, 0]}
                  name="Nights"
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </section>

      {sheet.notes.trim() ? (
        <section className="rounded-2xl bg-surface p-5 shadow-[var(--shadow-sheet)] sm:p-6">
          <h3 className="font-display text-xl font-medium tracking-tight">
            Notes
          </h3>
          <p className="mt-3 whitespace-pre-wrap text-sm leading-normal text-fg">
            {sheet.notes}
          </p>
        </section>
      ) : null}

      <p
        className={cn(
          "pb-2 text-center text-xs text-subtle",
        )}
      >
        Figures use elapsed days only — future dates are not scored.
      </p>
    </div>
  );
}
