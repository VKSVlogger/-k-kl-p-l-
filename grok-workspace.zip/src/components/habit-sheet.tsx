import { useEffect, useRef } from "react";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  SLEEP_HOURS,
  checkKey,
  daysInMonthKey,
  isWeekend,
  todayInfo,
  weekdayLetter,
} from "@/lib/habits/model";
import { useActiveSheet, useHabitStore } from "@/lib/habits/store";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";

function dayList(dim: number) {
  return Array.from({ length: dim }, (_, i) => i + 1);
}

export function HabitSheet() {
  const activeMonth = useHabitStore((s) => s.activeMonth);
  const setHabitName = useHabitStore((s) => s.setHabitName);
  const toggleCheck = useHabitStore((s) => s.toggleCheck);
  const setSleep = useHabitStore((s) => s.setSleep);
  const setNotes = useHabitStore((s) => s.setNotes);
  const clearMonth = useHabitStore((s) => s.clearMonth);
  const sheet = useActiveSheet();
  const dim = daysInMonthKey(activeMonth);
  const days = dayList(dim);
  const today = todayInfo();
  const scroller = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (activeMonth !== today.key) return;
    const root = scroller.current;
    const col = root?.querySelector<HTMLElement>(`[data-day="${today.day}"]`);
    if (!root || !col) return;
    const left = col.offsetLeft - root.clientWidth / 2 + col.offsetWidth / 2;
    root.scrollLeft = Math.max(0, left);
  }, [activeMonth, today.day, today.key]);

  return (
    <section className="sheet-card overflow-hidden rounded-2xl bg-surface shadow-[var(--shadow-sheet)]">
      <div className="flex items-center justify-between gap-3 border-b border-border px-4 py-3 sm:px-5">
        <p className="text-xs font-medium tracking-[0.14em] text-muted uppercase">
          Habits / days
        </p>
        <p className="hidden text-xs text-subtle md:block">
          Tap a cell to mark it. Swipe the grid on smaller screens.
        </p>
      </div>

      <div ref={scroller} className="overflow-x-auto">
        <table className="w-max min-w-full border-collapse text-sm md:w-full md:table-fixed">
          <thead>
            <tr>
              <th
                scope="col"
                className="sticky left-0 z-20 w-36 bg-surface px-2 py-2 text-left text-xs font-medium tracking-wide text-muted uppercase shadow-[1px_0_0_0_var(--color-border)] sm:w-44 sm:px-3"
              >
                Habit
              </th>
              {days.map((day) => {
                const isToday = activeMonth === today.key && day === today.day;
                const weekend = isWeekend(activeMonth, day);
                return (
                  <th
                    key={day}
                    scope="col"
                    data-day={day}
                    className={cn(
                      "px-0 py-1.5 text-center font-medium tabular-nums",
                      isToday
                        ? "bg-today text-accent"
                        : weekend
                          ? "bg-weekend text-muted"
                          : "text-muted",
                    )}
                  >
                    <span className="block text-xs font-medium leading-none text-subtle">
                      {weekdayLetter(activeMonth, day)}
                    </span>
                    <span className="mt-0.5 block text-xs leading-none">
                      {day}
                    </span>
                  </th>
                );
              })}
              <th
                scope="col"
                className="w-12 bg-surface px-1 py-2 text-right text-xs font-medium tracking-wide text-muted uppercase"
              >
                Sum
              </th>
            </tr>
          </thead>
          <tbody>
            {sheet.habits.map((habit, index) => {
              const done = days.reduce(
                (n, day) =>
                  n + (sheet.checks[checkKey(habit.id, day)] ? 1 : 0),
                0,
              );
              return (
                <tr key={habit.id} className="border-t border-border">
                  <th
                    scope="row"
                    className="sticky left-0 z-10 bg-surface px-1 py-0 shadow-[1px_0_0_0_var(--color-border)]"
                  >
                    <div className="flex items-center gap-1">
                      <span className="w-5 shrink-0 text-right text-xs tabular-nums text-subtle">
                        {index + 1}.
                      </span>
                      <input
                        value={habit.name}
                        onChange={(e) =>
                          setHabitName(habit.id, e.target.value)
                        }
                        placeholder="Add a habit"
                        aria-label={`Habit ${index + 1} name`}
                        suppressHydrationWarning
                        className="h-10 min-w-0 flex-1 bg-transparent px-1 text-sm font-medium text-fg outline-none placeholder:font-normal placeholder:text-subtle"
                      />
                    </div>
                  </th>
                  {days.map((day) => {
                    const on = Boolean(sheet.checks[checkKey(habit.id, day)]);
                    const isToday =
                      activeMonth === today.key && day === today.day;
                    const weekend = isWeekend(activeMonth, day);
                    const unnamed = habit.name.trim().length === 0;
                    return (
                      <td
                        key={day}
                        className={cn(
                          "p-0",
                          isToday ? "bg-today" : weekend ? "bg-weekend/70" : "",
                        )}
                      >
                        <button
                          type="button"
                          disabled={unnamed}
                          aria-pressed={on}
                          aria-label={`${habit.name || `Habit ${index + 1}`}, day ${day}${on ? ", complete" : ""}`}
                          onClick={() => toggleCheck(habit.id, day)}
                          className={cn(
                            "flex h-10 w-full min-w-9 items-center justify-center transition-[background-color,color] duration-150 disabled:cursor-not-allowed disabled:opacity-30 md:h-8 md:min-w-0",
                            on
                              ? "bg-accent text-accent-fg hover:bg-accent/90"
                              : "hover:bg-accent-soft",
                          )}
                        >
                          <Check
                            className={cn(
                              "size-3 transition-[opacity,transform] duration-150",
                              on ? "opacity-100 scale-100" : "opacity-0 scale-50",
                            )}
                            strokeWidth={3}
                          />
                        </button>
                      </td>
                    );
                  })}
                  <td className="px-1 text-right text-xs tabular-nums text-muted">
                    {habit.name.trim() ? done : "—"}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="border-t border-border">
        <div className="flex items-center justify-between gap-3 px-4 py-3 sm:px-5">
          <p className="text-xs font-medium tracking-[0.14em] text-muted uppercase">
            Sleep
          </p>
          <p className="hidden text-xs text-subtle sm:block">
            One mark per night
          </p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-max min-w-full border-collapse text-sm md:w-full md:table-fixed">
            <tbody>
              {SLEEP_HOURS.map((hours) => (
                <tr key={hours} className="border-t border-border">
                  <th
                    scope="row"
                    className="sticky left-0 z-10 w-36 bg-surface px-3 py-0 text-left text-sm font-medium shadow-[1px_0_0_0_var(--color-border)] sm:w-44"
                  >
                    <span className="flex h-10 items-center tabular-nums md:h-8">
                      {hours} hrs
                    </span>
                  </th>
                  {days.map((day) => {
                    const on = sheet.sleep[String(day)] === hours;
                    const isToday =
                      activeMonth === today.key && day === today.day;
                    const weekend = isWeekend(activeMonth, day);
                    return (
                      <td
                        key={day}
                        className={cn(
                          "p-0",
                          isToday ? "bg-today" : weekend ? "bg-weekend/70" : "",
                        )}
                      >
                        <button
                          type="button"
                          aria-pressed={on}
                          aria-label={`${hours} hours on day ${day}`}
                          onClick={() => setSleep(day, hours)}
                          className={cn(
                            "flex h-10 w-full min-w-9 items-center justify-center transition-[background-color,color] duration-150 md:h-8 md:min-w-0",
                            on
                              ? "bg-accent text-accent-fg hover:bg-accent/90"
                              : "hover:bg-accent-soft",
                          )}
                        >
                          <span
                            className={cn(
                              "size-1.5 rounded-full bg-accent-fg transition-opacity duration-150",
                              on ? "opacity-100" : "opacity-0",
                            )}
                          />
                        </button>
                      </td>
                    );
                  })}
                  <td className="w-12" />
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="border-t border-border px-4 py-4 sm:px-5 sm:py-5">
        <label className="block">
          <span className="text-xs font-medium tracking-[0.14em] text-muted uppercase">
            Notes
          </span>
          <Textarea
            value={sheet.notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="How the month felt, what to keep, what to drop."
            className="mt-2 min-h-28"
            rows={4}
          />
        </label>
        <div className="no-print mt-3 flex justify-end">
          <Button type="button" variant="ghost" size="sm" onClick={clearMonth}>
            Clear this month
          </Button>
        </div>
      </div>
    </section>
  );
}
