import { useEffect } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { AppHeader } from "@/components/app-header";
import { HabitSheet } from "@/components/habit-sheet";
import { MonthlyReport } from "@/components/monthly-report";
import { TodayPanel } from "@/components/today-panel";
import { useHabitStore } from "@/lib/habits/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const view = useHabitStore((s) => s.view);

  useEffect(() => {
    const rehydrate = useHabitStore.persist?.rehydrate;
    if (typeof rehydrate !== "function") return;
    try {
      void rehydrate();
    } catch {
      /* localStorage can be blocked; the in-memory sheet still works */
    }
  }, []);

  return (
    <main className="min-h-svh bg-bg px-4 py-6 sm:px-6 sm:py-10">
      <div className="mx-auto flex w-full max-w-6xl flex-col gap-6">
        <AppHeader />
        {view === "sheet" ? (
          <>
            <TodayPanel />
            <HabitSheet />
          </>
        ) : (
          <MonthlyReport />
        )}
      </div>
    </main>
  );
}
